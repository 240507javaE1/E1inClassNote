package sa;

import org.school;

public class A extends school {
	
	public String getName()
	{
		return "學生名:"+name;
	}

}
