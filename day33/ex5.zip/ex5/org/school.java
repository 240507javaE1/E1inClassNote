package org;

public class school {
	protected  String name;

	public String getName() {
		return "名:"+name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
