package sb;

import org.school;

public class B extends school {
	public String getName()
	{
		return "B班學生名:"+name;
	}


}
